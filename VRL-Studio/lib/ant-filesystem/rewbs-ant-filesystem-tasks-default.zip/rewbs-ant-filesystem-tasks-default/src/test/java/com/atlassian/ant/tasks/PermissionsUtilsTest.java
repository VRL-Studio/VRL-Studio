package com.atlassian.ant.tasks;

import static org.junit.Assert.assertEquals;

import java.io.File;
import java.io.IOException;
import java.util.Locale;

import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.MethodRule;
import org.junit.runner.RunWith;
import org.junit.runners.model.FrameworkMethod;
import org.junit.runners.model.Statement;
import org.mockito.runners.MockitoJUnitRunner;

@RunWith(MockitoJUnitRunner.class)
public class PermissionsUtilsTest
{
    @Rule
    public MethodRule ignoreOnWindows = new  MethodRule()
    {
        public Statement apply(final Statement base, final FrameworkMethod method, final Object target)
        {
            return new Statement () {
                @Override
                public void evaluate() throws Throwable
                {
                    if (!System.getProperty("os.name")
                        .toLowerCase(Locale.ENGLISH)
                        .startsWith("windows"))
                    {
                        base.evaluate();
                    }
                }
            };
        }
    };

    @Test
    public void testgetPermissions744() throws IOException
    {
        File file = File.createTempFile("mode", ".tmp");
        try
        {
            file.setExecutable(true, true);
            file.setWritable(true, true);
            file.setReadable(true, false);

            assertEquals(0744, PermissionsUtils.getPermissions(file));
        }
        finally
        {
            file.delete();
        }
    }

    @Test
    public void testgetPermissions444() throws IOException
    {
        File file = File.createTempFile("mode", ".tmp");
        try
        {
            file.setExecutable(false, false);
            file.setWritable(false, false);
            file.setReadable(true, true);

            assertEquals(0444, PermissionsUtils.getPermissions(file));
        }
        finally
        {
            file.delete();
        }
    }

    @Test
    public void testsetPermissions444() throws IOException
    {
        File file = File.createTempFile("mode", ".tmp");
        try
        {
            PermissionsUtils.setPermissions(file, 0444);
            assertEquals(0444, PermissionsUtils.getPermissions(file));
        }
        finally
        {
            file.delete();
        }
    }

    @Test
    public void testsetPermissions754() throws IOException
    {
        File file = File.createTempFile("mode", ".tmp");
        try
        {
            PermissionsUtils.setPermissions(file, 0754);
            assertEquals(0754, PermissionsUtils.getPermissions(file));
        }
        finally
        {
            file.delete();
        }
    }
}
