package org.jpedal.io;

public class Speech {
	
	static public String selectedVoice = "kevin16";
	
	static public boolean speechAvailible()
	{
        return false;
        /**/
	}
	
	public static String[] listVoices() {     
        return null;//*/
    }
	
	static public void speakText(String text)
	{
	}
}
