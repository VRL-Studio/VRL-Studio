/**
 * ===========================================
 * Java Pdf Extraction Decoding Access Library
 * ===========================================
 *
 * Project Info:  http://www.jpedal.org
 *
 * (C) Copyright 2011, IDRsolutions and Contributors.
 *
 * 	This file is part of JPedal
 *
     This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA


  *
  * ---------------

  * FontWriter.java
  * ---------------
  * (C) Copyright 2011, by IDRsolutions and Contributors.
  *
  *
  * --------------------------
 */
package org.jpedal.fonts.tt.conversion;

import org.jpedal.fonts.tt.FontFile2;
import org.jpedal.utils.Sorts;
import org.jpedal.utils.StringUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FontWriter extends FontFile2 {

    String name;

    int glyphCount;

    int headCheckSumPos=-1;

    public FontWriter(byte[] data) {
        super(data);
    }

    public FontWriter() {
    }

    /**
     * Retrieves a positive int from a specified number of bytes in supplied array
     * @param d Byte array to fetch from
     * @param startPoint Location of start of number
     * @param offsetSize Number of bytes occupied
     * @return Number found
     */
    static int getUintFromByteArray(byte[] d, int startPoint, int offsetSize) {
        int shift = (offsetSize-1) * 8;
        int result = 0;
        int offset = 0;
        while (shift >= 0) {
            int part = d[startPoint+offset];
            if (part < 0)
                part += 256;
            result = result | part << shift;
            offset++;
            shift = shift - 8;
        }

        return result;
    }

    /**
     * Retrieves a binary number of arbitrary length from the supplied int array, treating it as bytes
     * @param d int array to fetch from
     * @param startPoint Location of start of number
     * @param offsetSize Number of bytes occupied
     * @return Number found
     */
    static int getUintFromIntArray(int[] d, int startPoint, int offsetSize) {
        int shift = (offsetSize-1) * 8;
        int result = 0;
        int offset = 0;
        while (shift >= 0) {
            result = result | (d[startPoint+offset] & 0xFF) << shift;
            offset++;
            shift = shift - 8;
        }

        return result;
    }

    /**
     * Creates a Type 1c number as a byte array.
     * @param num Number to encode
     * @return byte array of number in type 1c format
     */
    static byte[] set1cNumber(int num) {
        byte[] result;

        if (num >= -107 && num <= 107) {
            result = new byte[]{(byte)(num + 139)};

        } else if (num >= 108 && num <= 1131) {
            num -= 108;
            result = new byte[]{(byte)(247+(num/256)),
                    (byte)(num & 0xFF)};

        } else if (num >= -1131 && num <= -108) {
            num += 108;
            result = new byte[]{(byte)(251+(num/-256)),
                    (byte)(-num & 0xFF)};

        } else if (num >= -32768 && num <= 32767) {
            result = new byte[]{28,
                    (byte)((num/256)&0xFF),
                    (byte)(num&0xFF)};

        } else {
            result = new byte[]{29,
                    (byte)((((num/256)/256)/256)&0xFF),
                    (byte)(((num/256)/256)&0xFF),
                    (byte)((num/256)&0xFF),
                    (byte)(num&0xFF)};
        }

        return result;
    }

    /**
     * Creates a Charstring Type 2 number as a byte array.
     * @param num Number to encode
     * @return byte array of number in charstring type 2 format
     */
    static byte[] setCharstringType2Number(int num) {
        byte[] result;

        if (num >= -107 && num <= 107) {
            result = new byte[]{(byte)(num + 139)};

        } else if (num >= 108 && num <= 1131) {
            num -= 108;
            result = new byte[]{(byte)(247+(num/256)),
                    (byte)(num & 0xFF)};

        } else if (num >= -1131 && num <= -108) {
            num += 108;
            result = new byte[]{(byte)(251+(num/-256)),
                    (byte)(-num & 0xFF)};

        } else {
            result = new byte[]{(byte)255,
                    (byte)((num/256)&0xFF),
                    (byte)(num&0xFF),
                    0,
                    0};
        }

        return result;
    }

    /**
     * Encode a number as a byte array of arbitrary length.
     * @param num The number to encode
     * @param byteCount The number of bytes to use
     * @return The number expressed in the required number of bytes
     */
    public static byte[] setUintAsBytes(int num, int byteCount) {
        byte[] result = new byte[byteCount];
        for (int i=byteCount; i>0; i--) {
            int part = num;
            for (int j=1; j<i; j++) {
                part = (part >> 8);
            }
            result[byteCount-i] = (byte)part;
        }

        return result;
    }

    static int createChecksum(byte[] table) {

        int checksumValue=0;

        FontFile2 checksum=new FontFile2(table,true);

        int longCount=((table.length+3)>>2);

        for(int j=0;j<longCount;j++){
            checksumValue=checksumValue+checksum.getNextUint32();
        }

        return checksumValue;
    }

    /**
     * return a short
     */
    final static public byte[] setUFWord(int rawValue) {

        short value=(short)rawValue;

        byte[] returnValue=new byte[2];

        for(int i=0;i<2;i++){
            returnValue[i]= (byte) ((value>>(8*(1-i)))& 255);
        }

        return returnValue;
    }

    /**
     * return a short
     */
    final static public byte[] setFWord(int rawValue) {

        short value=(short)rawValue;

        byte[] returnValue=new byte[2];

        for(int i=0;i<2;i++){
            returnValue[i]= (byte) ((value>>(8*(1-i)))& 255);
        }

        return returnValue;
    }

    /**
     * turn int back into byte[2]
     **/
    final static public byte[] setNextUint16(int value){

        byte[] returnValue=new byte[2];

        for(int i=0;i<2;i++){
            returnValue[i]= (byte) ((value>>(8*(1-i)))& 255);
        }
        return returnValue;
    }

    /**
     * turn int back into byte[2]
     **/
    final static public byte[] setNextInt16(int value){

        byte[] returnValue=new byte[2];

        for(int i=0;i<2;i++){
            returnValue[i]= (byte) ((value>>(8*(1-i)))& 255);
        }
        return returnValue;
    }

    /**
     * turn int back into byte[2]
     **/
    final static public byte[] setNextSignedInt16(short value){

        byte[] returnValue=new byte[2];

        for(int i=0;i<2;i++){
            returnValue[i]= (byte) ((value>>(8*(1-i)))& 255);
        }
        return returnValue;
    }

    /**
     * turn int back into byte
     **/
    final static public byte setNextUint8(int value){

        return (byte) (value& 255);

    }

    /**
     * turn int back into byte[4]
     **/
    final static public byte[] setNextUint32(int value){

        byte[] returnValue=new byte[4];

        for(int i=0;i<4;i++){
            returnValue[i]= (byte) ((value>>(8*(3-i)))& 255);
        }

        return returnValue;
    }

    /**
     * turn int back into byte[8]
     **/
    final static public byte[] setNextUint64(int value){

        byte[] returnValue=new byte[8];

        for(int i=0;i<8;i++){
            returnValue[i]= (byte) ((value>>(8*(7-i)))& 255);
        }

        return returnValue;
    }

    final static public byte[] setNextUint64(long value){

        byte[] returnValue=new byte[8];

        for(int i=0;i<8;i++){
            returnValue[i]= (byte) ((value>>(8*(7-i)))& 255);
        }

        return returnValue;
    }

    /**read the table tableLength*/
    final public byte[] writeFontToStream() throws IOException {

        readTables();

        ByteArrayOutputStream bos=new ByteArrayOutputStream();

        //version
        if(type==OPENTYPE) //OTF with glyf data
            bos.write(setNextUint32(1330926671));
        else if(type==TTC)
            bos.write(setNextUint32(1953784678));
        else
            bos.write(setNextUint32(65536));

        if(type==TTC){

            System.out.println("TTC write not implemented");

//            getNextUint32(); //version
//            fontCount=getNextUint32();
//
//            //location of tables
//            tables=new int[tableCount][fontCount];
//            tableLength=new int[tableCount][fontCount];
//
//            int[] fontOffsets=new int[fontCount];
//
//            for(int currentFont=0;currentFont<fontCount;currentFont++){
//
//                currentFontID=currentFont;
//
//                int fontStart=getNextUint32();
//                fontOffsets[currentFont]=fontStart;
//            }
//
//            for(int currentFont=0;currentFont<fontCount;currentFont++){
//
//                currentFontID=currentFont; //choose this font
//
//                this.pointer = fontOffsets[currentFont];
//
//                scalerType=getNextUint32();
//
//                readTablesForFont();
//            }
//
//            //back to default
//            currentFontID=0;


        }else{  //otf or ttf

            //location of tables
            //tables=new int[tableCount][1];
            //tableLength=new int[tableCount][1];

            writeTablesForFont(bos);
        }

        bos.flush();
        bos.close();
        byte[] fileInBytes=bos.toByteArray();

        /**
         * set HEAD checksum
         */
        byte[] headCheckSum=setNextUint32((int)(Long.parseLong("B1B0AFBA",16)-createChecksum(fileInBytes)));
        System.arraycopy(headCheckSum, 0, fileInBytes, 0 + headCheckSumPos, 4);

        return fileInBytes;
    }

    //empty base copy replaced by version from TT or PS
    void readTables() {

    }

    boolean debug=false;

    private void writeTablesForFont(ByteArrayOutputStream bos) throws IOException {

        int[] keys=new int[numTables];
        int[] offset=new int[numTables];
        int id;
        String tag;
        int[] checksum=new int[numTables];
        int[] tableSize=new int[numTables];

        /**
         * write out header
         */
        bos.write(setNextUint16(numTables));
        bos.write(setNextUint16(searchRange));
        bos.write(setNextUint16(entrySelector));
        bos.write(setNextUint16(rangeShift));

        /**
         * calc checksums
         */
        for(int l=0;l<numTables;l++){

            tag= (String) tableList.get(l);

            //read table value (including for head which is done differently at end)
            id= getTableID(tag);

            if(debug)
                System.out.println("writing out "+tag+" id="+id);

            if(id!=-1){
                byte[] tableBytes= this.getTableBytes(id);

                //head is set to zero here and replaced later
                if(id!=HEAD)
                    checksum[l]=createChecksum(tableBytes);

                tableSize[l]=tableBytes.length;

                //needed below to work out order in file
                keys[l]=l;
                offset[l]=tables[id][currentFontID];
            }
        }

        keys= Sorts.quicksort(offset, keys);

        int currentOffset=alignOnWordBoundary(bos.size()+(16*numTables));
        int[] fileOffset=new int[numTables];

        int i;
        /**
         * calc filePointer
         */
        for(int l=0;l<numTables;l++){

            i=keys[l];

            fileOffset[i]=currentOffset;

            offset[i]=currentOffset;

            currentOffset=alignOnWordBoundary(currentOffset+tableSize[i]);

        }

        /**
         * write out pointers
         */
        for(int j=0;j<numTables;j++){

            int l=j;//keys[j];
            tag= (String) tableList.get(l);

            bos.write(StringUtils.toBytes(tag));

            //read table value
            id= getTableID(tag);

            if(id!=-1){
                //byte[] table=this.getTableBytes(id);

                //flag pos to put in correct value later
                if(id==HEAD){
                    headCheckSumPos=bos.size();
                }

                bos.write(setNextUint32(checksum[l]));//checksum
                bos.write(setNextUint32(fileOffset[l])); //table pos
                bos.write(setNextUint32(tableSize[l])); //table length

            }
        }

        /**
         * write out actual tables in order
         */
        int sortedKey;
        byte[] bytes;
        for(int l=0;l<numTables;l++){

            sortedKey=keys[l];
            tag= (String) tableList.get(sortedKey);
            id= getTableID(tag);
            bytes=this.getTableBytes(id);

            //fill in any gaps (pad out to multiple of 4 byte blocks)
            while((bos.size() & 3) !=0){
                bos.write((byte)0);
            }

            bos.write(bytes);
        }
    }

    private static int alignOnWordBoundary(int currentOffset){
        //make sure on 4 byte boundary
        int packing = currentOffset & 3;
        if(packing!=0){
            currentOffset=currentOffset+(4-packing);
        }

        return currentOffset;
    }
}
